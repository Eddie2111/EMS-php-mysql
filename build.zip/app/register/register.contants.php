<?php
define('ERROR_REQUIRED_FIELDS', "All fields are required.");
define('ERROR_INVALID_EMAIL', "Invalid email format.");
define('ERROR_EMAIL_EXISTS', "Email is already registered.");
define('SUCCESS_REGISTRATION', "Registration successful! Please log in.");
define('SUCCESS_ACCOUNT_CREATED', "Account created successfully, log in now.");
define('ERROR_ACCOUNT_CREATION', "Failed to create account.");
