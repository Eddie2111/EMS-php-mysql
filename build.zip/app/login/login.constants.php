<?php
define('ERROR_REQUIRED_FIELDS', "Email and password are required.");
define('ERROR_INVALID_EMAIL', "Invalid email format.");
define('ERROR_INVALID_CREDENTIALS', "Invalid email or password.");
define('ERROR_LOGIN_FAILED', "An error occurred during login.");
define('SUCCESS_LOGIN', "Login successful! Welcome back.");
