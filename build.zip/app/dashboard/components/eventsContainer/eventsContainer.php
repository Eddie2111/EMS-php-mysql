<h1 class="mb-4 text-center">Events</h1>
<?php
include("./components/createEvent/createEventForm.php");
?>
<div class="my-5 container">
    <div id="event-grid" class="g-4 row"></div>
    <nav>
        <ul id="pagination" class="justify-content-center mt-4 pagination"></ul>
    </nav>
</div>

<script src="./components/eventsContainer/eventsContainer.js"></script>