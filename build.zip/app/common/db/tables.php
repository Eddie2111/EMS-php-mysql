<?php
define('USERS_TABLE', 'User');
define('EVENTS_TABLE', 'Event');
define('ATTENDEES_TABLE', 'Attendee');
define('ROLES_TABLE', 'Role');
?>