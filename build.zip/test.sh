docker exec -it mysql-db mysql -u root --password=mysql -e "SHOW DATABASES;"
